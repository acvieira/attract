=== More Taxonomies ===
Contributors: henrikmelin, kalstrom
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&#38;business=h.melin%40gmail.com&#38;item_name=More%20Types%20Plugin&#38;no_shipping=0&#38;no_note=1&#38;tax=0&#38;currency_code=USD&#38;bn=PP%2dDonationsBF&#38;charset=UTF%2d8&#38;lc=US
Tags: taxonomies, cms, post types, admin, more fields, wordpress 3.0, more types, types, more taxonomies
Requires at least: 3.2.1
Tested up to: 3.2.1
Stable tag: 1.1

Add more taxonomies to your WordPress installation.

== Description ==

This is an early beta - fixes and better documentation to come. Promise.

== Installation ==

To install More Fields:

1. Upload the 'more-taxonomies' folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Setup your new post types in Settings -> More Taxonomies

